# VPS Prediksi Dashboard — BBFS 7 Digit Utama

## Arsitektur
```
Data JSON → VPS Analyzer (Node.js) → JSON statis → index.html (browser)
```
Browser hanya membaca JSON. Semua analisis berjalan di VPS.

## Struktur
```
prediksi/
├── index.html              ← Frontend dashboard (self-contained)
├── assets/css/             ← CSS
├── assets/js/              ← JS logika frontend
├── data/
│   ├── all_results_from_source_file.json  ← Input data
│   └── generated/          ← Output JSON (auto-generated)
│       ├── manifest.json
│       ├── markets.json
│       ├── latest_next_draw.json
│       ├── latest_backtest.json
│       ├── latest_rolling_validation.json
│       ├── latest_holdout_recent_test.json
│       ├── latest_model_objective.json
│       └── markets/        ← Per-pasaran JSON
├── server/
│   ├── analyze_fast.js     ← Analyzer utama (Node.js)
│   ├── config.json         ← Konfigurasi
│   ├── run_analysis.sh     ← Shell runner
│   └── lib/                ← Library modules
└── logs/                   ← Log files
```

## Cara Jalankan
```bash
cd /var/www/html/prediksi
node server/analyze_fast.js --markets=57
```

## Cron (setiap hari jam 06:00 dan 18:00)
```
0 6,18 * * * /usr/bin/node /var/www/html/prediksi/server/analyze_fast.js --markets=57
```

## Disclaimer
Dashboard ini menampilkan **ranking statistik berdasarkan data historis**.
Bukan angka pasti, bukan bocoran, bukan jaminan hasil.
