#!/bin/bash
# ─────────────────────────────────────────────────────────────
# run_analysis.sh — VPS Prediksi Analyzer Runner
# Jalankan: bash /var/www/html/prediksi/server/run_analysis.sh
# ─────────────────────────────────────────────────────────────
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

echo "[$(date -Iseconds)] Starting VPS analysis..."
node "$SCRIPT_DIR/analyze_fast.js" --markets=57

echo "[$(date -Iseconds)] Analysis complete. Outputs in: $BASE_DIR/data/generated/"
