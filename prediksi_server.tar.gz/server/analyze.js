'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const { loadData, validateAndGroup } = require('./lib/data-loader');
const { gen2D, gen3D, genBBFS2D, genBBFS3D } = require('./lib/candidate-generator');
const { computeFeatures } = require('./lib/feature-engineering');
const { scoreAndRank } = require('./lib/scoring');
const { runBacktest, runBacktestSampled } = require('./lib/backtest');
const { runRollingValidation } = require('./lib/rolling-validation');
const { runHoldoutTest } = require('./lib/holdout-test');
const { runRandomSimulation, runSimpleBaseline } = require('./lib/random-simulation');
const { computeObjective, normalizeObjectiveScores } = require('./lib/objective-function');
const { calibrateConfidence, confidenceInterval, computePredictionGate } = require('./lib/confidence');
const { checkOverfitting } = require('./lib/overfitting-guard');
const { generateBBFS } = require('./lib/bbfs');
const { writeJSON, ensureDir, writeMarketOutput, hashConfig } = require('./lib/output-writer');

// ─────────────────────────────────────────────
// PATHS
// ─────────────────────────────────────────────
const BASE_DIR = path.resolve(__dirname, '..');
const DATA_DIR = path.join(BASE_DIR, 'data');
const INPUT_FILE = path.join(DATA_DIR, 'all_results_from_source_file.json');
const OUTPUT_DIR = path.join(DATA_DIR, 'generated');
const LOG_FILE = path.join(BASE_DIR, 'logs', 'analysis.log');
const ERR_FILE = path.join(BASE_DIR, 'logs', 'analysis-error.log');
const LOCK_FILE = path.join(BASE_DIR, 'logs', 'analysis.lock');
const CONFIG_FILE = path.join(__dirname, 'config.json');

const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
const CONFIG_HASH = hashConfig(config);
const SCHEMA_VERSION = config.schema_version || '1.0.0';
const ANALYZER_VERSION = config.analyzer_version || '1.0.0';
const SEED = config.seed || 123456789;
const MIN_VALID = config.min_valid_rows || 31;
const MIN_TRAIN = config.min_training_rows || 30;
const HOLDOUT_RATIO = config.holdout_ratio || 0.10;
const SIM_COUNT = config.simulation_count || 1000;
const BBFS_COUNT = config.bbfs_digit_count || 7;
const BBFS_REPEAT = config.bbfs_repeat_allowed !== false;
const PRESETS = config.weight_presets;
const TOP_K = config.max_top_candidates_display || 10;

// ─────────────────────────────────────────────
// ARGUMENT PARSING
// ─────────────────────────────────────────────
const args = process.argv.slice(2);
const modeArg = args.find(a => a.startsWith('--mode='));
const MODE = modeArg ? modeArg.replace('--mode=','') : 'max';
const BBFS_FLAG = args.includes('--bbfs') || true; // always generate BBFS
const marketFilter = args.find(a=>a.startsWith('--market='));
const MARKET_FILTER = marketFilter ? marketFilter.replace('--market=','').toUpperCase() : null;

// ─────────────────────────────────────────────
// LOGGING
// ─────────────────────────────────────────────
ensureDir(path.join(BASE_DIR, 'logs'));
ensureDir(OUTPUT_DIR);
ensureDir(path.join(OUTPUT_DIR, 'markets'));
ensureDir(path.join(OUTPUT_DIR, 'checkpoints'));

function log(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}\n`;
  process.stdout.write(line);
  try { fs.appendFileSync(LOG_FILE, line); } catch(_) {}
}
function logErr(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ERROR: ${msg}\n`;
  process.stderr.write(line);
  try { fs.appendFileSync(ERR_FILE, line); } catch(_) {}
}

// ─────────────────────────────────────────────
// LOCK FILE
// ─────────────────────────────────────────────
function acquireLock() {
  if (fs.existsSync(LOCK_FILE)) {
    try {
      const lockData = JSON.parse(fs.readFileSync(LOCK_FILE,'utf8'));
      const pid = lockData.pid;
      // Check if PID is still alive
      try { process.kill(pid, 0); return false; } catch(_) { /* stale */ }
      log('Stale lock detected. Removing stale lock file.');
      fs.unlinkSync(LOCK_FILE);
    } catch(_) { try { fs.unlinkSync(LOCK_FILE); } catch(__) {} }
  }
  writeJSON(LOCK_FILE, { pid: process.pid, started_at: new Date().toISOString(), mode: MODE });
  return true;
}
function releaseLock() { try { if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE); } catch(_) {} }

// ─────────────────────────────────────────────
// DISCLAIMER
// ─────────────────────────────────────────────
const DISCLAIMER = 'Dashboard ini hanya menampilkan ranking statistik berdasarkan data historis, backtest, rolling validation, holdout recent test, ensemble scoring, objective function, dan perbandingan terhadap baseline random serta baseline sederhana. Hasil analisis bukan jaminan angka akan keluar, bukan angka pasti, dan tidak boleh dianggap sebagai kepastian hasil.';
const BBFS_DISCLAIMER = 'BBFS 7 Digit Utama adalah ruang kandidat statistik historis yang dibentuk berdasarkan data historis, validasi, backtest, rolling validation, holdout recent test, baseline random, baseline sederhana, confidence calibration, dan guard anti-overfitting. Hasil ini bukan angka pasti, bukan bocoran, bukan jaminan hasil, dan bukan instruksi taruhan.';

// ─────────────────────────────────────────────
// MAIN ANALYSIS PER MARKET
// ─────────────────────────────────────────────
function analyzeMarket(pasaran, rawRecords, inputHash, allWarnings) {
  log(`Analyzing market: ${pasaran} (${rawRecords.length} records)`);

  const validData = rawRecords.filter(r => r.valid_result);
  const nValid = validData.length;
  const invalidData = rawRecords.filter(r => !r.valid_result);

  const latestRecord = rawRecords[rawRecords.length - 1] || {};
  const latestDate = latestRecord.tanggal || '-';
  const latestResult = latestRecord.result || '-';

  // Data freshness
  const now = new Date();
  const lastDate = new Date(latestDate);
  const daysDiff = isNaN(lastDate) ? 999 : Math.floor((now - lastDate) / 86400000);
  const dataFreshness = daysDiff > (config.data_freshness_stale_days || 7) ? 'STALE' :
                        isNaN(lastDate) ? 'UNKNOWN' : 'FRESH';

  if (nValid < MIN_VALID) {
    log(`  ${pasaran}: insufficient data (${nValid} < ${MIN_VALID})`);
    allWarnings.push({ pasaran, issue: 'INSUFFICIENT_DATA', count: nValid });
    return buildInsufficientDataOutput(pasaran, rawRecords, nValid, inputHash, latestDate, latestResult, dataFreshness);
  }

  const candidates2D = gen2D();
  const candidates3D = gen3D();

  // ── PRESET SELECTION (nested model search) ──────────────
  log(`  ${pasaran}: running preset selection (${PRESETS.length} presets × 2D+3D)`);
  const presetResults2D = [];
  const presetResults3D = [];

  for (const preset of PRESETS) {
    // 2D backtest (sampled for speed)
    const step2d = nValid > 300 ? 3 : 1;
    const bt2d = runBacktestSampled(validData, candidates2D, '2d', preset, MIN_TRAIN, step2d);
    if (!bt2d) { presetResults2D.push({ preset, bt: null, obj: null }); continue; }

    // Rolling validation (light)
    const rolling2d = runRollingValidation(validData, candidates2D, '2d', preset, MIN_TRAIN);
    // Simple baseline
    const simple2d = runSimpleBaseline(validData, candidates2D, '2d', MIN_TRAIN);
    const obj2d = computeObjective(bt2d, null, null, rolling2d, simple2d, nValid, '2d');
    presetResults2D.push({ preset, bt: bt2d, rolling: rolling2d, simple: simple2d, obj: obj2d });

    // 3D backtest (more heavily sampled)
    const step3d = nValid > 100 ? 8 : 4;
    const bt3d = runBacktestSampled(validData, candidates3D, '3d', preset, MIN_TRAIN, step3d);
    if (!bt3d) { presetResults3D.push({ preset, bt: null, obj: null }); continue; }
    const rolling3d = runRollingValidation(validData, candidates3D, '3d', preset, MIN_TRAIN);
    const simple3d = runSimpleBaseline(validData, candidates3D, '3d', MIN_TRAIN);
    const obj3d = computeObjective(bt3d, null, null, rolling3d, simple3d, nValid, '3d');
    presetResults3D.push({ preset, bt: bt3d, rolling: rolling3d, simple: simple3d, obj: obj3d });
  }

  normalizeObjectiveScores(presetResults2D);
  normalizeObjectiveScores(presetResults3D);

  // Select champion model
  const champion2D = presetResults2D.sort((a,b) => (b.obj_score_normalized||0)-(a.obj_score_normalized||0))[0];
  const champion3D = presetResults3D.sort((a,b) => (b.obj_score_normalized||0)-(a.obj_score_normalized||0))[0];

  // Challengers: within 20% of champion score
  const challengers2D = presetResults2D.filter(r => r !== champion2D && r.obj_score_normalized >= (champion2D.obj_score_normalized||0) * 0.80).slice(0,3);
  const challengers3D = presetResults3D.filter(r => r !== champion3D && r.obj_score_normalized >= (champion3D.obj_score_normalized||0) * 0.80).slice(0,3);

  log(`  ${pasaran}: champion 2D=${champion2D.preset.name} (${Math.round(champion2D.obj_score_normalized||0)}), 3D=${champion3D.preset.name} (${Math.round(champion3D.obj_score_normalized||0)})`);

  // ── FULL BACKTEST WITH CHAMPION ───────────────────────────
  log(`  ${pasaran}: running full backtest...`);
  const fullBT2D = runBacktest(validData, candidates2D, '2d', champion2D.preset, MIN_TRAIN);
  const step3dFull = nValid > 200 ? 3 : 1;
  const fullBT3D = runBacktestSampled(validData, candidates3D, '3d', champion3D.preset, MIN_TRAIN, step3dFull);

  // ── HOLDOUT TEST ─────────────────────────────────────────
  log(`  ${pasaran}: running holdout test...`);
  const holdout2D = runHoldoutTest(validData, candidates2D, '2d', champion2D.preset, MIN_TRAIN, HOLDOUT_RATIO);
  const holdout3D_step = nValid > 200 ? 3 : 1;
  const holdout3D = runHoldoutTest(validData.slice(0, Math.floor(nValid*(1-HOLDOUT_RATIO))), candidates3D, '3d', champion3D.preset, MIN_TRAIN, HOLDOUT_RATIO);

  // ── ROLLING VALIDATION (FULL) ─────────────────────────────
  const rolling2D = champion2D.rolling || runRollingValidation(validData, candidates2D, '2d', champion2D.preset, MIN_TRAIN);
  const rolling3D = champion3D.rolling || runRollingValidation(validData, candidates3D, '3d', champion3D.preset, MIN_TRAIN);

  // ── RANDOM SIMULATION ────────────────────────────────────
  log(`  ${pasaran}: running random simulation...`);
  const randSim2D = runRandomSimulation(fullBT2D.total, 100, Math.min(SIM_COUNT, 500), SEED);
  const randSim3D = runRandomSimulation(fullBT3D ? fullBT3D.total : 0, 1000, Math.min(SIM_COUNT, 200), SEED);

  // ── OVERFITTING GUARD ─────────────────────────────────────
  const overfit2D = checkOverfitting(fullBT2D, holdout2D, rolling2D);
  const overfit3D = checkOverfitting(fullBT3D, holdout3D, rolling3D);

  // ── CONFIDENCE INTERVAL ───────────────────────────────────
  const ci2D = confidenceInterval(fullBT2D.hits10 || 0, fullBT2D.total || 0);
  const ci3D = fullBT3D ? confidenceInterval(fullBT3D.hits10 || 0, fullBT3D.total || 0) : null;

  // ── PREDICTION GATE ───────────────────────────────────────
  const predGate2D = computePredictionGate(fullBT2D, rolling2D, holdout2D, nValid, '2d');
  const predGate3D = computePredictionGate(fullBT3D, rolling3D, holdout3D, nValid, '3d');

  // ── CONFIDENCE CALIBRATION ────────────────────────────────
  const simple2D = champion2D.simple || runSimpleBaseline(validData, candidates2D, '2d', MIN_TRAIN);
  const simple3D = champion3D.simple || runSimpleBaseline(validData, candidates3D, '3d', MIN_TRAIN);

  const conf2D = calibrateConfidence({
    type:'2d', n_valid:nValid, bt:fullBT2D, rolling:rolling2D,
    holdout:holdout2D, randSim:randSim2D, simpleBaseline:simple2D,
    has_overfitting:overfit2D.has_overfitting
  });
  const conf3D = calibrateConfidence({
    type:'3d', n_valid:nValid, bt:fullBT3D, rolling:rolling3D,
    holdout:holdout3D, randSim:randSim3D, simpleBaseline:simple3D,
    has_overfitting:overfit3D.has_overfitting
  });

  // ── FINAL SCORING FOR NEXT DRAW ───────────────────────────
  log(`  ${pasaran}: computing final rankings...`);
  const allFeatures2D = computeFeatures(validData, candidates2D, '2d');
  const allScored2D = scoreAndRank(allFeatures2D, champion2D.preset);
  const allFeatures3D = computeFeatures(validData, candidates3D, '3d');
  const allScored3D = scoreAndRank(allFeatures3D, champion3D.preset);

  // ── BBFS GENERATION ───────────────────────────────────────
  log(`  ${pasaran}: generating BBFS 7 Digit Utama...`);
  const bbfsResult = generateBBFS(
    validData, allScored2D, allScored3D,
    fullBT2D, fullBT3D, rolling2D, rolling3D,
    holdout2D, holdout3D, predGate2D, null, config
  );

  const bbfsDigits = bbfsResult.selected_digits;
  const bbfsCands2D = genBBFS2D(bbfsDigits, BBFS_REPEAT);
  const bbfsCands3D = genBBFS3D(bbfsDigits, BBFS_REPEAT);

  // Re-rank BBFS candidates
  const bbfsFeatures2D = computeFeatures(validData, bbfsCands2D, '2d');
  const bbfsScored2D = scoreAndRank(bbfsFeatures2D, champion2D.preset);
  const bbfsFeatures3D = computeFeatures(validData, bbfsCands3D, '3d');
  const bbfsScored3D = scoreAndRank(bbfsFeatures3D, champion3D.preset);

  const top10_2d_bbfs = bbfsScored2D.slice(0, TOP_K).map(s => ({
    rank: s.rank, candidate: s.candidate, score: Math.round(s.score * 10) / 10,
    confidence: conf2D.level,
    reason: buildReason2D(s, allFeatures2D[s.candidate], champion2D, conf2D, bbfsResult)
  }));
  const top10_3d_bbfs = bbfsScored3D.slice(0, TOP_K).map(s => ({
    rank: s.rank, candidate: s.candidate, score: Math.round(s.score * 10) / 10,
    confidence: conf3D.level,
    reason: buildReason3D(s, allFeatures3D[s.candidate], champion3D, conf3D, bbfsResult)
  }));

  // ── SIMPLE BASELINE (full) ────────────────────────────────
  const bt2d_rand10 = 10/100;
  const bt3d_rand10 = 10/1000;
  const rand_status_2d = fullBT2D.acc10 > bt2d_rand10 ? 'LEBIH_BAIK' : fullBT2D.acc10 >= bt2d_rand10 * 0.9 ? 'SETARA' : 'LEBIH_BURUK';
  const rand_status_3d = fullBT3D && fullBT3D.acc10 > bt3d_rand10 ? 'LEBIH_BAIK' : 'SETARA';

  // Collect warnings
  const mktWarnings = [];
  if (dataFreshness === 'STALE') mktWarnings.push({ type:'DATA_STALE', msg:`Data terakhir ${daysDiff} hari yang lalu` });
  if (overfit2D.has_overfitting) mktWarnings.push({ type:'OVERFITTING_2D', msg:overfit2D.reasons.join('; ') });
  if (overfit3D.has_overfitting) mktWarnings.push({ type:'OVERFITTING_3D', msg:overfit3D.reasons.join('; ') });
  if (!rolling2D.is_stable) mktWarnings.push({ type:'ROLLING_UNSTABLE_2D', msg:'Rolling validation 2D tidak stabil' });
  if (!rolling3D.is_stable) mktWarnings.push({ type:'ROLLING_UNSTABLE_3D', msg:'Rolling validation 3D tidak stabil' });

  // ── BUILD MARKET OUTPUT ───────────────────────────────────
  const now_iso = new Date().toISOString();

  const marketOut = {
    schema_version: SCHEMA_VERSION,
    generated_at: now_iso,
    analyzer_version: ANALYZER_VERSION,
    mode: MODE,
    seed: SEED,
    input_hash: inputHash,

    pasaran,
    total_rows: rawRecords.length,
    valid_rows: nValid,
    invalid_rows: invalidData.length,
    duplicate_rows: rawRecords.filter(r=>r.is_dup).length,
    latest_date: latestDate,
    latest_result: latestResult,
    data_freshness: dataFreshness,
    eligible_for_prediction: nValid >= MIN_VALID,

    // BBFS
    bbfs_enabled: true,
    bbfs_status: bbfsResult.bbfs_status,
    bbfs_digits: bbfsDigits,
    bbfs_confidence: bbfsResult.bbfs_confidence,
    bbfs_limiters: bbfsResult.bbfs_limiters,
    bbfs_candidates_2d_count: bbfsCands2D.length,
    bbfs_candidates_3d_count: bbfsCands3D.length,
    selected_digit_reasons: bbfsResult.selected_digit_reasons,
    rejected_digits: bbfsResult.rejected_digits,
    rejected_digit_reasons: bbfsResult.rejected_digit_reasons,
    all_digit_scores: bbfsResult.all_digit_scores,
    display_mode: 'BBFS',

    // Predictions from BBFS
    top10_2d_from_bbfs: top10_2d_bbfs,
    top10_3d_from_bbfs: top10_3d_bbfs,
    display_candidates_2d: top10_2d_bbfs,
    display_candidates_3d: top10_3d_bbfs,

    // Prediction gate
    prediction_gate_2d: predGate2D,
    prediction_gate_3d: predGate3D,
    allowed_max_confidence_2d: conf2D.level,
    allowed_max_confidence_3d: conf3D.level,
    confidence_limiters_2d: conf2D.limiters,
    confidence_limiters_3d: conf3D.limiters,

    // Backtest
    backtest_2d: {
      total: fullBT2D.total,
      acc5: r2(fullBT2D.acc5), acc10: r2(fullBT2D.acc10), acc20: r2(fullBT2D.acc20),
      baseline_rand10: bt2d_rand10, baseline_rand20: 20/100,
      uplift_top10: r2((fullBT2D.acc10 - bt2d_rand10)/Math.max(bt2d_rand10,0.001)),
      mrr: r4(fullBT2D.mrr), avg_rank: r2(fullBT2D.avgRank), med_rank: r2(fullBT2D.medRank),
      sim_random_avg10: r2(randSim2D.avg10),
      random_status: rand_status_2d,
      champion_model: champion2D.preset.name,
      obj_score: Math.round(champion2D.obj_score_normalized||0)
    },
    backtest_3d: fullBT3D ? {
      total: fullBT3D.total,
      acc5: r2(fullBT3D.acc5), acc10: r2(fullBT3D.acc10), acc20: r2(fullBT3D.acc20),
      baseline_rand10: bt3d_rand10, baseline_rand20: 20/1000,
      uplift_top10: r2((fullBT3D.acc10 - bt3d_rand10)/Math.max(bt3d_rand10,0.001)),
      mrr: r4(fullBT3D.mrr), avg_rank: r2(fullBT3D.avgRank), med_rank: r2(fullBT3D.medRank),
      random_status: rand_status_3d,
      champion_model: champion3D.preset.name,
      obj_score: Math.round(champion3D.obj_score_normalized||0)
    } : null,

    // Rolling validation
    rolling_2d: { slices: rolling2D.slices, stability_score: r2(rolling2D.stability_score), is_stable: rolling2D.is_stable, status: rolling2D.overall_status },
    rolling_3d: { slices: rolling3D.slices, stability_score: r2(rolling3D.stability_score), is_stable: rolling3D.is_stable, status: rolling3D.overall_status },

    // Holdout
    holdout_2d: {
      status: holdout2D.status,
      train_count: holdout2D.train_count, holdout_count: holdout2D.holdout_count,
      holdout_from: holdout2D.holdout_from, holdout_to: holdout2D.holdout_to,
      acc10: holdout2D.acc10 !== undefined ? r2(holdout2D.acc10) : null,
      acc20: holdout2D.acc20 !== undefined ? r2(holdout2D.acc20) : null,
      baseline_rand10: bt2d_rand10,
      uplift10: holdout2D.uplift10 !== undefined ? r2(holdout2D.uplift10) : null,
      max_confidence_after_holdout: holdout2D.max_confidence_after_holdout || 'MEDIUM',
      penalty_reasons: holdout2D.penalty_reasons || [],
      overfitting_recent_status: holdout2D.overfitting_recent_status || 'ACCEPTABLE'
    },
    holdout_3d: {
      status: holdout3D.status,
      train_count: holdout3D.train_count, holdout_count: holdout3D.holdout_count,
      acc10: holdout3D.acc10 !== undefined ? r2(holdout3D.acc10) : null,
      max_confidence_after_holdout: holdout3D.max_confidence_after_holdout || 'MEDIUM',
      penalty_reasons: holdout3D.penalty_reasons || []
    },

    // Confidence interval
    ci_2d: { lower: r4(ci2D.lower), upper: r4(ci2D.upper), n: ci2D.n, warning: ci2D.warning },
    ci_3d: ci3D ? { lower: r4(ci3D.lower), upper: r4(ci3D.upper), n: ci3D.n } : null,

    // Overfitting guard
    overfitting_2d: { has_overfitting: overfit2D.has_overfitting, risk_level: overfit2D.risk_level, reasons: overfit2D.reasons },
    overfitting_3d: { has_overfitting: overfit3D.has_overfitting, risk_level: overfit3D.risk_level, reasons: overfit3D.reasons },

    // Champion vs challenger
    champion_challenger_2d: {
      champion: { name: champion2D.preset.name, obj_score: Math.round(champion2D.obj_score_normalized||0) },
      challengers: challengers2D.map(c => ({ name:c.preset.name, obj_score: Math.round(c.obj_score_normalized||0) }))
    },
    champion_challenger_3d: {
      champion: { name: champion3D.preset.name, obj_score: Math.round(champion3D.obj_score_normalized||0) },
      challengers: challengers3D.map(c => ({ name:c.preset.name, obj_score: Math.round(c.obj_score_normalized||0) }))
    },

    // Random simulation
    rand_sim_2d: { avg10: r4(randSim2D.avg10), avg20: r4(randSim2D.avg20), sims: randSim2D.sims, theory10: bt2d_rand10 },
    rand_sim_3d: { avg10: r4(randSim3D.avg10), sims: randSim3D.sims, theory10: bt3d_rand10 },

    // Simple baseline
    simple_baseline_2d: simple2D,
    simple_baseline_3d: simple3D,

    // Full audit candidates (not shown as main output)
    full_candidate_space_used_for_audit: true,
    hidden_full_space_rankings_available_for_audit: true,
    audit_top10_2d_full: allScored2D.slice(0,10).map(s=>({ candidate:s.candidate, score:Math.round(s.score*10)/10, rank:s.rank })),
    audit_top10_3d_full: allScored3D.slice(0,10).map(s=>({ candidate:s.candidate, score:Math.round(s.score*10)/10, rank:s.rank })),

    // Historical records (most recent 50 for display)
    recent_history: rawRecords.slice(-50).reverse().map(r=>({
      tanggal: r.tanggal, result: r.result, d3: r.d3, d2: r.d2,
      status_result: r.status_result, status_date: r.status_date, is_dup: r.is_dup
    })),

    warnings: mktWarnings,
    disclaimer: DISCLAIMER,
    bbfs_disclaimer: BBFS_DISCLAIMER
  };

  return marketOut;
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function r2(v) { return v !== undefined && v !== null ? Math.round(v * 100) / 100 : null; }
function r4(v) { return v !== undefined && v !== null ? Math.round(v * 10000) / 10000 : null; }

function buildReason2D(scored, feat, champion, conf, bbfs) {
  if (!feat) return 'Kandidat dari BBFS 7 Digit Utama.';
  const parts = [];
  if (feat.is_hot_short) parts.push('panas jangka pendek');
  if (feat.is_stable) parts.push('stabil lintas periode');
  if (feat.gap_score > 0.6) parts.push('gap sehat');
  if (feat.dpos_score > 0.6) parts.push('digit-position kuat');
  parts.push(`model champion: ${champion.preset.name}`);
  if (conf.limiters.length > 0) parts.push(`confidence dibatasi: ${conf.limiters[0]}`);
  return `Kandidat dari BBFS 7 Digit Utama. ${parts.join('; ')}.`;
}
function buildReason3D(scored, feat, champion, conf, bbfs) {
  if (!feat) return 'Kandidat dari BBFS 7 Digit Utama.';
  const parts = [];
  if (feat.dpos_score > 0.5) parts.push('digit-position mendukung');
  if (feat.gap_score > 0.5) parts.push('gap cukup sehat');
  parts.push(`model champion: ${champion.preset.name}`);
  if (conf.limiters.length > 0) parts.push(`confidence dibatasi: ${conf.limiters[0]}`);
  return `Kandidat dari BBFS 7 Digit Utama. ${parts.join('; ')}.`;
}

function buildInsufficientDataOutput(pasaran, rawRecords, nValid, inputHash, latestDate, latestResult, dataFreshness) {
  return {
    schema_version: SCHEMA_VERSION,
    generated_at: new Date().toISOString(),
    analyzer_version: ANALYZER_VERSION,
    mode: MODE, seed: SEED, input_hash: inputHash,
    pasaran, total_rows: rawRecords.length, valid_rows: nValid,
    invalid_rows: rawRecords.filter(r=>!r.valid_result).length,
    duplicate_rows: rawRecords.filter(r=>r.is_dup).length,
    latest_date: latestDate, latest_result: latestResult,
    data_freshness: dataFreshness, eligible_for_prediction: false,
    bbfs_enabled: false, bbfs_status: 'BBFS_UNAVAILABLE',
    prediction_gate_2d: { status:'TIDAK_LAYAK_PREDIKSI', reason:'Data tidak cukup (< 31 result valid)' },
    prediction_gate_3d: { status:'TIDAK_LAYAK_PREDIKSI', reason:'Data tidak cukup' },
    display_candidates_2d: [], display_candidates_3d: [],
    warnings: [{ type:'INSUFFICIENT_DATA', msg:`Hanya ${nValid} data valid. Minimal ${MIN_VALID} diperlukan.` }],
    recent_history: rawRecords.slice(-20).reverse().map(r=>({
      tanggal:r.tanggal, result:r.result, d3:r.d3, d2:r.d2, status_result:r.status_result
    })),
    disclaimer: DISCLAIMER
  };
}

// ─────────────────────────────────────────────
// MAIN ENTRY POINT
// ─────────────────────────────────────────────
async function main() {
  const startTime = Date.now();
  log(`=== ANALYZER START === mode=${MODE} bbfs=${BBFS_FLAG}`);

  // Acquire lock
  if (!acquireLock()) {
    logErr('Analisis sebelumnya masih berjalan. Proses baru dibatalkan untuk mencegah output JSON rusak.');
    process.exit(1);
  }

  const allWarnings = [];
  let loadResult;

  try {
    // Load data
    log('Loading input data...');
    loadResult = loadData(INPUT_FILE);
    log(`Loaded ${loadResult.raw_data.length} records. Hash: ${loadResult.input_hash}`);

    // Validate and group
    log('Validating and grouping data...');
    const { markets, validCount, invalidCount, dupCount, warnings } = validateAndGroup(loadResult.raw_data);
    allWarnings.push(...warnings.slice(0, 100));

    const marketNames = Object.keys(markets).filter(m => MARKET_FILTER ? m === MARKET_FILTER : true);
    log(`Markets to analyze: ${marketNames.length}`);

    const now_iso = new Date().toISOString();
    const marketSummary = [];
    const allMarketOutputs = {};

    // ── ANALYZE EACH MARKET ──────────────────────────────────
    for (const pasaran of marketNames) {
      try {
        const out = analyzeMarket(pasaran, markets[pasaran], loadResult.input_hash, allWarnings);
        allMarketOutputs[pasaran] = out;
        writeMarketOutput(OUTPUT_DIR, pasaran, out);
        marketSummary.push({
          pasaran,
          total_rows: out.total_rows,
          valid_rows: out.valid_rows,
          invalid_rows: out.invalid_rows,
          duplicate_rows: out.duplicate_rows || 0,
          latest_date: out.latest_date,
          latest_result: out.latest_result,
          data_freshness: out.data_freshness,
          eligible_for_prediction: out.eligible_for_prediction,
          bbfs_digits: out.bbfs_digits || null,
          prediction_gate_2d: out.prediction_gate_2d ? out.prediction_gate_2d.status : null,
          confidence_2d: out.allowed_max_confidence_2d || null
        });
      } catch(e) {
        logErr(`Market ${pasaran} failed: ${e.message}`);
        allWarnings.push({ pasaran, issue:'ANALYSIS_ERROR', msg: e.message });
        marketSummary.push({ pasaran, total_rows: markets[pasaran].length, eligible_for_prediction: false, error: e.message });
      }
    }

    // ── WRITE GLOBAL OUTPUT FILES ────────────────────────────
    log('Writing global output files...');

    // manifest.json
    const manifest = {
      schema_version: SCHEMA_VERSION,
      generated_at: now_iso,
      mode: MODE, input_file: path.basename(INPUT_FILE),
      input_total_rows: loadResult.raw_data.length,
      input_hash: loadResult.input_hash,
      input_file_size: loadResult.input_file_size,
      input_last_modified: loadResult.input_last_modified,
      valid_total_rows: validCount,
      invalid_total_rows: invalidCount,
      total_markets: marketNames.length,
      analyzer_version: ANALYZER_VERSION,
      seed: SEED,
      warnings_count: allWarnings.length,
      status: 'OK',
      bbfs_enabled: BBFS_FLAG,
      config_hash: CONFIG_HASH,
      duration_ms: Date.now() - startTime
    };
    writeJSON(path.join(OUTPUT_DIR, 'manifest.json'), manifest);

    // markets.json
    writeJSON(path.join(OUTPUT_DIR, 'markets.json'), {
      schema_version: SCHEMA_VERSION,
      generated_at: now_iso,
      markets: marketSummary
    });

    // latest_next_draw.json - aggregate top predictions
    const latestNextDraw = {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      analyzer_version: ANALYZER_VERSION, mode: MODE, seed: SEED,
      input_hash: loadResult.input_hash,
      bbfs_enabled: true, display_mode: 'BBFS',
      full_candidate_space_used_for_audit: true,
      hidden_full_space_rankings_available_for_audit: true,
      markets: marketSummary.map(m => {
        const mo = allMarketOutputs[m.pasaran];
        if (!mo) return { pasaran: m.pasaran, eligible: false };
        return {
          pasaran: m.pasaran,
          eligible_for_prediction: mo.eligible_for_prediction,
          data_freshness: mo.data_freshness,
          bbfs_status: mo.bbfs_status,
          bbfs_digits: mo.bbfs_digits,
          bbfs_confidence: mo.bbfs_confidence,
          prediction_gate_2d: mo.prediction_gate_2d,
          prediction_gate_3d: mo.prediction_gate_3d,
          top10_2d_from_bbfs: mo.top10_2d_from_bbfs || [],
          top10_3d_from_bbfs: mo.top10_3d_from_bbfs || [],
          display_candidates_2d: mo.display_candidates_2d || [],
          display_candidates_3d: mo.display_candidates_3d || [],
          bbfs_confidence_limiter: mo.bbfs_limiters || [],
          allowed_max_confidence_2d: mo.allowed_max_confidence_2d,
          allowed_max_confidence_3d: mo.allowed_max_confidence_3d,
          bbfs_holdout_penalty_status: mo.holdout_2d ? mo.holdout_2d.status : null,
          bbfs_overfitting_status: mo.overfitting_2d ? mo.overfitting_2d.risk_level : null,
          latest_date: mo.latest_date, latest_result: mo.latest_result
        };
      }),
      disclaimer: DISCLAIMER, bbfs_disclaimer: BBFS_DISCLAIMER
    };
    writeJSON(path.join(OUTPUT_DIR, 'latest_next_draw.json'), latestNextDraw);

    // latest_backtest.json
    const latestBacktest = {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      markets: marketSummary.map(m => {
        const mo = allMarketOutputs[m.pasaran];
        return { pasaran: m.pasaran, backtest_2d: mo ? mo.backtest_2d : null, backtest_3d: mo ? mo.backtest_3d : null };
      })
    };
    writeJSON(path.join(OUTPUT_DIR, 'latest_backtest.json'), latestBacktest);

    // latest_rolling_validation.json
    const latestRolling = {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      markets: marketSummary.map(m => {
        const mo = allMarketOutputs[m.pasaran];
        return { pasaran: m.pasaran, rolling_2d: mo ? mo.rolling_2d : null, rolling_3d: mo ? mo.rolling_3d : null };
      })
    };
    writeJSON(path.join(OUTPUT_DIR, 'latest_rolling_validation.json'), latestRolling);

    // latest_holdout_recent_test.json
    const latestHoldout = {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      markets: marketSummary.map(m => {
        const mo = allMarketOutputs[m.pasaran];
        return { pasaran: m.pasaran, holdout_2d: mo ? mo.holdout_2d : null, holdout_3d: mo ? mo.holdout_3d : null };
      })
    };
    writeJSON(path.join(OUTPUT_DIR, 'latest_holdout_recent_test.json'), latestHoldout);

    // latest_model_objective.json
    const latestModelObj = {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      markets: marketSummary.map(m => {
        const mo = allMarketOutputs[m.pasaran];
        return {
          pasaran: m.pasaran,
          champion_challenger_2d: mo ? mo.champion_challenger_2d : null,
          champion_challenger_3d: mo ? mo.champion_challenger_3d : null
        };
      })
    };
    writeJSON(path.join(OUTPUT_DIR, 'latest_model_objective.json'), latestModelObj);

    // latest_warnings.json
    writeJSON(path.join(OUTPUT_DIR, 'latest_warnings.json'), {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      total: allWarnings.length,
      warnings: allWarnings.slice(0, 200)
    });

    // latest_summary.json
    const eligible = marketSummary.filter(m => m.eligible_for_prediction).length;
    writeJSON(path.join(OUTPUT_DIR, 'latest_summary.json'), {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      total_markets: marketNames.length,
      eligible_markets: eligible,
      total_records: loadResult.raw_data.length,
      valid_records: validCount, invalid_records: invalidCount,
      bbfs_enabled: BBFS_FLAG,
      disclaimer: DISCLAIMER,
      duration_ms: Date.now() - startTime,
      mode: MODE
    });

    // latest_analyzer_config_snapshot.json
    writeJSON(path.join(OUTPUT_DIR, 'latest_analyzer_config_snapshot.json'), {
      schema_version: SCHEMA_VERSION, generated_at: now_iso,
      analyzer_version: ANALYZER_VERSION, mode: MODE, seed: SEED,
      input_hash: loadResult.input_hash,
      input_file: path.basename(INPUT_FILE),
      input_file_size: loadResult.input_file_size,
      input_last_modified: loadResult.input_last_modified,
      config_hash: CONFIG_HASH,
      candidate_space_2d: 100, candidate_space_3d: 1000,
      weight_presets_count: PRESETS.length,
      holdout_ratio: HOLDOUT_RATIO,
      simulation_count: SIM_COUNT,
      bbfs_digit_count: BBFS_COUNT,
      bbfs_repeat_allowed: BBFS_REPEAT,
      min_valid_rows: MIN_VALID,
      min_training_rows: MIN_TRAIN
    });

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    log(`=== ANALYZER COMPLETE === ${marketNames.length} markets in ${elapsed}s`);

  } catch(e) {
    logErr('FATAL: ' + e.message + '\n' + e.stack);
    try {
      writeJSON(path.join(OUTPUT_DIR, 'latest_warnings.json'), {
        schema_version: SCHEMA_VERSION, generated_at: new Date().toISOString(),
        total: 1, warnings: [{ issue:'FATAL_ERROR', msg: e.message }]
      });
    } catch(_) {}
    releaseLock();
    process.exit(1);
  }

  releaseLock();
  process.exit(0);
}

main().catch(e => { logErr(e.message); releaseLock(); process.exit(1); });
