'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const BASE_DIR = path.resolve('/home/claude/prediksi');
const DATA_DIR = path.join(BASE_DIR, 'data');
const INPUT_FILE = path.join(DATA_DIR, 'all_results_from_source_file.json');
const OUTPUT_DIR = path.join(DATA_DIR, 'generated');
const LOG_FILE = path.join(BASE_DIR, 'logs', 'analysis.log');

const CONFIG = JSON.parse(fs.readFileSync(path.join(BASE_DIR,'server','config.json'),'utf8'));
const PRESETS = CONFIG.weight_presets;
const MIN_VALID = CONFIG.min_valid_rows || 31;
const MIN_TRAIN = CONFIG.min_training_rows || 30;
const HOLDOUT_RATIO = CONFIG.holdout_ratio || 0.10;
const SEED = CONFIG.seed || 123456789;
const BBFS_REPEAT = CONFIG.bbfs_repeat_allowed !== false;
const TOP_K = CONFIG.max_top_candidates_display || 10;
const SCHEMA_VERSION = CONFIG.schema_version || '1.0.0';
const ANALYZER_VERSION = CONFIG.analyzer_version || '1.0.0';

// Add server lib to require path
const LIB = path.join(BASE_DIR,'server','lib');
const { computeFeatures } = require(path.join(LIB,'feature-engineering'));
const { scoreAndRank } = require(path.join(LIB,'scoring'));
const { gen2D, gen3D, genBBFS2D, genBBFS3D } = require(path.join(LIB,'candidate-generator'));
const { runBacktestFast } = require(path.join(LIB,'backtest-fast'));
const { runRollingFast } = require(path.join(LIB,'rolling-fast'));
const { runRandomSimulation } = require(path.join(LIB,'random-simulation'));
const { computeObjective, normalizeObjectiveScores } = require(path.join(LIB,'objective-function'));
const { calibrateConfidence, confidenceInterval, computePredictionGate } = require(path.join(LIB,'confidence'));
const { checkOverfitting } = require(path.join(LIB,'overfitting-guard'));
const { generateBBFS } = require(path.join(LIB,'bbfs'));

const DISCLAIMER = 'Hasil ini adalah ranking statistik berdasarkan data historis, backtest, rolling validation, holdout, dan ensemble scoring. Bukan jaminan angka akan keluar, bukan bocoran, dan tidak boleh dianggap sebagai kepastian hasil.';
const BBFS_DISCLAIMER = 'BBFS 7 Digit Utama dibentuk dari analisis statistik historis dengan backtest, rolling validation, holdout recent test, guard anti-overfitting, dan objective function numerik. Ini bukan angka pasti dan bukan instruksi taruhan.';

function ensureDir(d){ fs.mkdirSync(d,{recursive:true}); }
function writeJSON(p,d){
  const tmp=p+'.tmp.'+Date.now();
  fs.writeFileSync(tmp,JSON.stringify(d,null,2),'utf8');
  fs.renameSync(tmp,p);
}
function log(m){
  const line=`[${new Date().toISOString()}] ${m}\n`;
  process.stdout.write(line);
  try{fs.appendFileSync(LOG_FILE,line);}catch(_){}
}
function r2(v){return v!=null?Math.round(v*100)/100:null;}
function r4(v){return v!=null?Math.round(v*10000)/10000:null;}

ensureDir(OUTPUT_DIR);
ensureDir(path.join(OUTPUT_DIR,'markets'));
ensureDir(path.join(BASE_DIR,'logs'));

// ─── PARSE ARGS ────────────────────────────────────
const args = process.argv.slice(2);
const mkArg = args.find(a=>a.startsWith('--markets='));
const MARKET_LIMIT = mkArg ? parseInt(mkArg.replace('--markets=','')) : 57;

// ─── LOAD DATA ────────────────────────────────────
log('Loading data...');
const raw = JSON.parse(fs.readFileSync(INPUT_FILE,'utf8'));
const rawArr = Array.isArray(raw)?raw:raw.data;
const inputHash = crypto.createHash('sha256').update(JSON.stringify(rawArr.length)).digest('hex').slice(0,12);
log(`Loaded ${rawArr.length} records`);

// ─── GROUP BY MARKET ──────────────────────────────
const markets = {};
for(const r of rawArr){
  const p=(r.pasaran||'').trim().toUpperCase();
  if(!p) continue;
  if(!markets[p]) markets[p]=[];
  const d2=r['2d_belakang']&&/^\d{2}$/.test(r['2d_belakang'])?r['2d_belakang']:null;
  const d3=r['3d_belakang']&&/^\d{3}$/.test(r['3d_belakang'])?r['3d_belakang']:null;
  markets[p].push({tanggal:r.tanggal,result:r.result,d2,d3,valid_result:!!(d2&&d3)});
}
// Sort each market oldest->newest
for(const m in markets) markets[m].sort((a,b)=>a.tanggal<b.tanggal?-1:1);

const marketNames = Object.keys(markets).slice(0, MARKET_LIMIT);
log(`Markets to analyze: ${marketNames.length}`);

const cands2D = gen2D();
const cands3D = gen3D();

const marketSummary = [];
const allOutputs = {};
const startTime = Date.now();

// ─── ANALYZE EACH MARKET ──────────────────────────
for(const pasaran of marketNames){
  const tMkt = Date.now();
  log(`Analyzing: ${pasaran}`);
  const recs = markets[pasaran];
  const validData = recs.filter(r=>r.valid_result && r.d2 && r.d3);
  const nValid = validData.length;
  const latest = recs[recs.length-1]||{};
  const latestDate = latest.tanggal||'-';
  const latestResult = latest.result||'-';
  const now = new Date();
  const daysDiff = isNaN(new Date(latestDate))?999:Math.floor((now-new Date(latestDate))/86400000);
  const freshness = daysDiff<=7?'FRESH':'STALE';

  if(nValid < MIN_VALID){
    const out = {schema_version:SCHEMA_VERSION,generated_at:new Date().toISOString(),pasaran,total_rows:recs.length,valid_rows:nValid,latest_date:latestDate,latest_result:latestResult,data_freshness:freshness,eligible_for_prediction:false,bbfs_enabled:false,bbfs_status:'BBFS_UNAVAILABLE',prediction_gate_2d:{status:'TIDAK_LAYAK_PREDIKSI',reason:'Data valid < 31'},prediction_gate_3d:{status:'TIDAK_LAYAK_PREDIKSI',reason:'Data valid < 31'},display_candidates_2d:[],display_candidates_3d:[],recent_history:recs.slice(-20).reverse(),warnings:[{type:'INSUFFICIENT_DATA',msg:`Hanya ${nValid} data valid.`}],disclaimer:DISCLAIMER};
    writeJSON(path.join(OUTPUT_DIR,'markets',pasaran.replace(/[^a-zA-Z0-9]/g,'_')+'.json'),out);
    allOutputs[pasaran]=out;
    marketSummary.push({pasaran,total_rows:recs.length,valid_rows:nValid,eligible_for_prediction:false,bbfs_status:'BBFS_UNAVAILABLE',latest_date:latestDate,data_freshness:freshness});
    continue;
  }

  // ── PRESET SELECTION (10 test points per preset) ────
  const presetsToTest = PRESETS;
  const presetRes2D=[], presetRes3D=[];

  for(const preset of presetsToTest){
    const bt2d = runBacktestFast(validData,cands2D,'2d',preset,MIN_TRAIN,12);
    const bt3d = runBacktestFast(validData,cands3D,'3d',preset,MIN_TRAIN,8);
    const obj2d = bt2d?computeObjective(bt2d,null,null,{stability_score:0.5},{win_rate:0.5},nValid,'2d'):{score_raw:0};
    const obj3d = bt3d?computeObjective(bt3d,null,null,{stability_score:0.5},{win_rate:0.5},nValid,'3d'):{score_raw:0};
    presetRes2D.push({preset,bt:bt2d,obj:obj2d});
    presetRes3D.push({preset,bt:bt3d,obj:obj3d});
  }
  normalizeObjectiveScores(presetRes2D);
  normalizeObjectiveScores(presetRes3D);
  presetRes2D.sort((a,b)=>(b.obj_score_normalized||0)-(a.obj_score_normalized||0));
  presetRes3D.sort((a,b)=>(b.obj_score_normalized||0)-(a.obj_score_normalized||0));

  const champ2D = presetRes2D[0];
  const champ3D = presetRes3D[0];
  const challengers2D = presetRes2D.slice(1,4);
  const challengers3D = presetRes3D.slice(1,4);

  // ── FULL BACKTEST (25 points) ────────────────────
  const fullBT2D = runBacktestFast(validData,cands2D,'2d',champ2D.preset,MIN_TRAIN,25);
  const fullBT3D = runBacktestFast(validData,cands3D,'3d',champ3D.preset,MIN_TRAIN,15);

  // ── ROLLING VALIDATION ───────────────────────────
  const rolling2D = runRollingFast(validData,cands2D,'2d',champ2D.preset,MIN_TRAIN);
  const rolling3D = runRollingFast(validData,cands3D,'3d',champ3D.preset,MIN_TRAIN);

  // ── HOLDOUT (10% most recent, 10 test points) ───
  const trainCut = Math.floor(nValid*(1-HOLDOUT_RATIO));
  const holdoutData = validData.slice(trainCut);
  let holdout2D={status:'HOLDOUT_TOO_SMALL',max_confidence_after_holdout:'MEDIUM',penalty_reasons:[],train_count:trainCut,holdout_count:holdoutData.length};
  if(holdoutData.length>=10){
    const step=Math.max(1,Math.ceil(holdoutData.length/10));
    let h10=0,cnt=0;
    const rand10=0.10;
    for(let i=0;i<holdoutData.length;i+=step){
      const train=validData.slice(0,trainCut+i);
      const actual=holdoutData[i].d2;
      if(!actual) continue;
      const feat=computeFeatures(train,cands2D,'2d');
      const sc=scoreAndRank(feat,champ2D.preset);
      const pos=sc.findIndex(s=>s.candidate===actual);
      const rank=pos<0?100:pos+1;
      if(rank<=10)h10++;
      cnt++;
    }
    const a10=cnt>0?h10/cnt:0;
    const u10=(a10-rand10)/Math.max(rand10,0.001);
    const maxConf=a10<=rand10?'LOW':a10<rand10*1.2?'MEDIUM':'HIGH';
    const hFrom=holdoutData[0].tanggal,hTo=holdoutData[holdoutData.length-1].tanggal;
    holdout2D={status:maxConf==='LOW'?'HOLDOUT_POOR':maxConf==='MEDIUM'?'HOLDOUT_LIMITED':'HOLDOUT_GOOD',train_count:trainCut,holdout_count:holdoutData.length,holdout_from:hFrom,holdout_to:hTo,acc10:r2(a10),baseline_rand10:rand10,uplift10:r2(u10),max_confidence_after_holdout:maxConf,penalty_reasons:maxConf==='LOW'?['Holdout acc10 <= random']:maxConf==='MEDIUM'?['Holdout marginal']:[]};
  }

  // ── RANDOM SIMULATION ────────────────────────────
  function makeRNG(seed){
    let s=seed>>>0;
    return()=>{s=Math.imul(1664525,s)+1013904223>>>0;return s/4294967295;};
  }
  const rng=makeRNG(SEED);
  let rSum10=0;
  const rSims=200;
  const nT=fullBT2D.total||1;
  for(let sim=0;sim<rSims;sim++){
    let h=0;
    for(let t=0;t<nT;t++){const rank=Math.floor(rng()*100)+1;if(rank<=10)h++;}
    rSum10+=h/nT;
  }
  const randSim2D={avg10:r4(rSum10/rSims),theory10:0.10,sims:rSims};

  // ── OVERFITTING GUARD ────────────────────────────
  const overfit2D = checkOverfitting(fullBT2D,holdout2D,rolling2D);
  const overfit3D = checkOverfitting(fullBT3D,null,rolling3D);

  // ── CI ───────────────────────────────────────────
  const ci2D = confidenceInterval(fullBT2D.hits10||0,fullBT2D.total||0);

  // ── PREDICTION GATE ──────────────────────────────
  const predGate2D = computePredictionGate(fullBT2D,rolling2D,holdout2D,nValid,'2d');
  const predGate3D = computePredictionGate(fullBT3D,rolling3D,null,nValid,'3d');

  // ── CONFIDENCE ───────────────────────────────────
  const conf2D = calibrateConfidence({type:'2d',n_valid:nValid,bt:fullBT2D,rolling:rolling2D,holdout:holdout2D,randSim:randSim2D,simpleBaseline:{win_rate:0.5},has_overfitting:overfit2D.has_overfitting});
  const conf3D = calibrateConfidence({type:'3d',n_valid:nValid,bt:fullBT3D,rolling:rolling3D,holdout:null,randSim:{avg10:0.01},simpleBaseline:{win_rate:0.5},has_overfitting:overfit3D.has_overfitting});

  // ── FINAL RANKING ────────────────────────────────
  const feat2D = computeFeatures(validData,cands2D,'2d');
  const scored2D = scoreAndRank(feat2D,champ2D.preset);
  const feat3D = computeFeatures(validData,cands3D,'3d');
  const scored3D = scoreAndRank(feat3D,champ3D.preset);

  // ── BBFS ────────────────────────────────────────
  const bbfsResult = generateBBFS(validData,scored2D,scored3D,fullBT2D,fullBT3D,rolling2D,rolling3D,holdout2D,null,predGate2D,null,CONFIG);
  const bbfsDigits = bbfsResult.selected_digits;
  const bbfsCands2D = genBBFS2D(bbfsDigits,BBFS_REPEAT);
  const bbfsCands3D = genBBFS3D(bbfsDigits,BBFS_REPEAT);

  // Re-rank BBFS candidates
  const bbfsFeat2D = computeFeatures(validData,bbfsCands2D,'2d');
  const bbfsScored2D = scoreAndRank(bbfsFeat2D,champ2D.preset);
  const bbfsFeat3D = computeFeatures(validData,bbfsCands3D,'3d');
  const bbfsScored3D = scoreAndRank(bbfsFeat3D,champ3D.preset);

  const top10_2d = bbfsScored2D.slice(0,TOP_K).map(s=>({
    rank:s.rank, candidate:s.candidate, score:r2(s.score), confidence:conf2D.level,
    reason:'Kandidat dari BBFS 7 Digit Utama. Model: '+champ2D.preset.name+(conf2D.limiters.length?' | Limiters: '+conf2D.limiters.slice(0,1).join(''):'')+'.'
  }));
  const top10_3d = bbfsScored3D.slice(0,TOP_K).map(s=>({
    rank:s.rank, candidate:s.candidate, score:r2(s.score), confidence:conf3D.level,
    reason:'Kandidat dari BBFS 7 Digit Utama. Model: '+champ3D.preset.name+'.'
  }));

  const warnings=[];
  if(freshness==='STALE') warnings.push({type:'DATA_STALE',msg:`Data terakhir ${daysDiff} hari lalu`});
  if(overfit2D.has_overfitting) warnings.push({type:'OVERFITTING_2D',msg:overfit2D.reasons.join('; ')});
  if(!rolling2D.is_stable) warnings.push({type:'ROLLING_UNSTABLE_2D',msg:'Rolling validation 2D tidak stabil'});

  const elapsed_mkt = ((Date.now()-tMkt)/1000).toFixed(1);
  log(`  Done ${pasaran} in ${elapsed_mkt}s | BT2D acc10=${r2(fullBT2D.acc10)} conf=${conf2D.level} BBFS=${bbfsDigits.join('')}`);

  const out={
    schema_version:SCHEMA_VERSION, generated_at:new Date().toISOString(),
    analyzer_version:ANALYZER_VERSION, mode:'max', seed:SEED, input_hash:inputHash,
    pasaran, total_rows:recs.length, valid_rows:nValid, invalid_rows:recs.length-nValid,
    latest_date:latestDate, latest_result:latestResult, data_freshness:freshness,
    eligible_for_prediction:true,

    bbfs_enabled:true, bbfs_status:bbfsResult.bbfs_status,
    bbfs_digits:bbfsDigits, bbfs_confidence:bbfsResult.bbfs_confidence,
    bbfs_limiters:bbfsResult.bbfs_limiters,
    bbfs_candidates_2d_count:bbfsCands2D.length, bbfs_candidates_3d_count:bbfsCands3D.length,
    selected_digit_reasons:bbfsResult.selected_digit_reasons,
    rejected_digits:bbfsResult.rejected_digits,
    rejected_digit_reasons:bbfsResult.rejected_digit_reasons,
    all_digit_scores:bbfsResult.all_digit_scores,
    display_mode:'BBFS',

    top10_2d_from_bbfs:top10_2d, top10_3d_from_bbfs:top10_3d,
    display_candidates_2d:top10_2d, display_candidates_3d:top10_3d,

    prediction_gate_2d:predGate2D, prediction_gate_3d:predGate3D,
    allowed_max_confidence_2d:conf2D.level, allowed_max_confidence_3d:conf3D.level,
    confidence_limiters_2d:conf2D.limiters, confidence_limiters_3d:conf3D.limiters,

    backtest_2d:{total:fullBT2D.total,acc5:r2(fullBT2D.acc5),acc10:r2(fullBT2D.acc10),acc20:r2(fullBT2D.acc20),baseline_rand10:0.10,uplift_top10:r2((fullBT2D.acc10-0.10)/0.10),mrr:r4(fullBT2D.mrr),avg_rank:r2(fullBT2D.avgRank),med_rank:r2(fullBT2D.medRank),sim_random_avg10:randSim2D.avg10,champion_model:champ2D.preset.name,obj_score:Math.round(champ2D.obj_score_normalized||0)},
    backtest_3d:{total:fullBT3D.total,acc10:r2(fullBT3D.acc10),acc20:r2(fullBT3D.acc20),baseline_rand10:0.01,champion_model:champ3D.preset.name},

    rolling_2d:{slices:rolling2D.slices,stability_score:r2(rolling2D.stability_score),is_stable:rolling2D.is_stable,status:rolling2D.overall_status},
    rolling_3d:{slices:rolling3D.slices,stability_score:r2(rolling3D.stability_score),is_stable:rolling3D.is_stable},

    holdout_2d:holdout2D,
    ci_2d:{lower:r4(ci2D.lower),upper:r4(ci2D.upper),n:ci2D.n},
    overfitting_2d:{has_overfitting:overfit2D.has_overfitting,risk_level:overfit2D.risk_level,reasons:overfit2D.reasons},
    overfitting_3d:{has_overfitting:overfit3D.has_overfitting,risk_level:overfit3D.risk_level,reasons:overfit3D.reasons},

    champion_challenger_2d:{champion:{name:champ2D.preset.name,obj_score:Math.round(champ2D.obj_score_normalized||0)},challengers:challengers2D.map(c=>({name:c.preset.name,obj_score:Math.round(c.obj_score_normalized||0)}))},
    champion_challenger_3d:{champion:{name:champ3D.preset.name,obj_score:Math.round(champ3D.obj_score_normalized||0)},challengers:challengers3D.map(c=>({name:c.preset.name,obj_score:Math.round(c.obj_score_normalized||0)}))},

    rand_sim_2d:randSim2D,
    audit_top10_2d_full:scored2D.slice(0,10).map(s=>({candidate:s.candidate,score:r2(s.score),rank:s.rank})),
    audit_top10_3d_full:scored3D.slice(0,10).map(s=>({candidate:s.candidate,score:r2(s.score),rank:s.rank})),

    recent_history:recs.slice(-50).reverse().map(r=>({tanggal:r.tanggal,result:r.result,d3:r.d3,d2:r.d2})),
    warnings,
    disclaimer:DISCLAIMER, bbfs_disclaimer:BBFS_DISCLAIMER
  };

  writeJSON(path.join(OUTPUT_DIR,'markets',pasaran.replace(/[^a-zA-Z0-9]/g,'_')+'.json'),out);
  allOutputs[pasaran]=out;
  marketSummary.push({pasaran,total_rows:recs.length,valid_rows:nValid,eligible_for_prediction:true,bbfs_status:bbfsResult.bbfs_status,bbfs_digits:bbfsDigits,prediction_gate_2d:predGate2D.status,confidence_2d:conf2D.level,latest_date:latestDate,latest_result:latestResult,data_freshness:freshness});
}

// ─── WRITE GLOBAL FILES ───────────────────────────
log('Writing global output files...');
const now_iso = new Date().toISOString();

writeJSON(path.join(OUTPUT_DIR,'manifest.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,analyzer_version:ANALYZER_VERSION,mode:'max',input_file:'all_results_from_source_file.json',input_total_rows:rawArr.length,input_hash:inputHash,total_markets:marketNames.length,seed:SEED,bbfs_enabled:true,status:'OK',duration_ms:Date.now()-startTime});

writeJSON(path.join(OUTPUT_DIR,'markets.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,markets:marketSummary});

const allEligible=marketSummary.filter(m=>m.eligible_for_prediction);
writeJSON(path.join(OUTPUT_DIR,'latest_next_draw.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,analyzer_version:ANALYZER_VERSION,mode:'max',seed:SEED,input_hash:inputHash,bbfs_enabled:true,display_mode:'BBFS',full_candidate_space_used_for_audit:true,markets:marketSummary.map(m=>{
  const mo=allOutputs[m.pasaran];
  if(!mo||!mo.eligible_for_prediction)return{pasaran:m.pasaran,eligible:false,latest_date:m.latest_date};
  return{pasaran:m.pasaran,eligible_for_prediction:true,data_freshness:mo.data_freshness,bbfs_status:mo.bbfs_status,bbfs_digits:mo.bbfs_digits,bbfs_confidence:mo.bbfs_confidence,prediction_gate_2d:mo.prediction_gate_2d,prediction_gate_3d:mo.prediction_gate_3d,top10_2d_from_bbfs:mo.top10_2d_from_bbfs,top10_3d_from_bbfs:mo.top10_3d_from_bbfs,display_candidates_2d:mo.display_candidates_2d,display_candidates_3d:mo.display_candidates_3d,allowed_max_confidence_2d:mo.allowed_max_confidence_2d,allowed_max_confidence_3d:mo.allowed_max_confidence_3d,latest_date:mo.latest_date,latest_result:mo.latest_result};
}),disclaimer:DISCLAIMER,bbfs_disclaimer:BBFS_DISCLAIMER});

writeJSON(path.join(OUTPUT_DIR,'latest_backtest.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,markets:marketSummary.map(m=>{const mo=allOutputs[m.pasaran];return{pasaran:m.pasaran,backtest_2d:mo?mo.backtest_2d:null,backtest_3d:mo?mo.backtest_3d:null};})});
writeJSON(path.join(OUTPUT_DIR,'latest_rolling_validation.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,markets:marketSummary.map(m=>{const mo=allOutputs[m.pasaran];return{pasaran:m.pasaran,rolling_2d:mo?mo.rolling_2d:null,rolling_3d:mo?mo.rolling_3d:null};})});
writeJSON(path.join(OUTPUT_DIR,'latest_holdout_recent_test.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,markets:marketSummary.map(m=>{const mo=allOutputs[m.pasaran];return{pasaran:m.pasaran,holdout_2d:mo?mo.holdout_2d:null};})});
writeJSON(path.join(OUTPUT_DIR,'latest_model_objective.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,markets:marketSummary.map(m=>{const mo=allOutputs[m.pasaran];return{pasaran:m.pasaran,champion_challenger_2d:mo?mo.champion_challenger_2d:null,champion_challenger_3d:mo?mo.champion_challenger_3d:null};})});
writeJSON(path.join(OUTPUT_DIR,'latest_summary.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,total_markets:marketNames.length,eligible_markets:allEligible.length,total_records:rawArr.length,bbfs_enabled:true,disclaimer:DISCLAIMER,duration_ms:Date.now()-startTime,mode:'max'});
writeJSON(path.join(OUTPUT_DIR,'latest_analyzer_config_snapshot.json'),{schema_version:SCHEMA_VERSION,generated_at:now_iso,analyzer_version:ANALYZER_VERSION,mode:'max',seed:SEED,input_hash:inputHash,candidate_space_2d:100,candidate_space_3d:1000,weight_presets_count:PRESETS.length,holdout_ratio:HOLDOUT_RATIO,bbfs_digit_count:7,bbfs_repeat_allowed:BBFS_REPEAT,min_valid_rows:MIN_VALID,min_training_rows:MIN_TRAIN});

const totalElapsed=((Date.now()-startTime)/1000).toFixed(1);
log(`=== ANALYZER COMPLETE === ${marketNames.length} markets in ${totalElapsed}s`);
