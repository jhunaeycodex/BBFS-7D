'use strict';

// ─────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────
let currentMarket = null;
let currentTab = '2d';
let allMarkets = [];

// ─────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  buildSidebar();
  renderTopbarInfo();

  // Select first eligible market
  const summary = MARKETS_SUMMARY.markets || [];
  const first = summary.find(m => m.eligible_for_prediction) || summary[0];
  if (first) selectMarket(getMarketKey(first.pasaran));

  // Search
  document.getElementById('search').addEventListener('input', e => {
    filterSidebar(e.target.value.trim().toLowerCase());
  });
});

function getMarketKey(pasaran) {
  return pasaran.replace(/[^a-zA-Z0-9]/g, '_');
}

// ─────────────────────────────────────────────
// TOPBAR INFO
// ─────────────────────────────────────────────
function renderTopbarInfo() {
  const ts = MANIFEST.generated_at
    ? new Date(MANIFEST.generated_at).toLocaleString('id-ID', {day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})
    : '-';
  document.getElementById('topbar-info').innerHTML =
    `<b>${MANIFEST.total_markets || 0}</b> pasaran &nbsp;|&nbsp; ` +
    `<b>${(MANIFEST.input_total_rows||0).toLocaleString()}</b> data &nbsp;|&nbsp; ` +
    `Gen: <b>${ts}</b> &nbsp;|&nbsp; v${MANIFEST.analyzer_version||'1.0'}`;
}

// ─────────────────────────────────────────────
// SIDEBAR
// ─────────────────────────────────────────────
function buildSidebar() {
  const summary = MARKETS_SUMMARY.markets || [];
  allMarkets = summary;
  const container = document.getElementById('mkt-list');
  container.innerHTML = '';

  for (const m of summary) {
    container.appendChild(buildMarketItem(m));
  }
}

function buildMarketItem(m) {
  const key = getMarketKey(m.pasaran);
  const conf = m.confidence_2d || (m.eligible_for_prediction ? 'MEDIUM' : null);
  const dotClass = conf === 'HIGH' ? 'dot-high' : conf === 'MEDIUM' ? 'dot-med' : conf === 'LOW' ? 'dot-low' : 'dot-na';
  const badgeClass = conf === 'HIGH' ? 'badge-high' : conf === 'MEDIUM' ? 'badge-med' : conf === 'LOW' ? 'badge-low' : 'badge-na';
  const badgeText = conf || 'N/A';

  const div = document.createElement('div');
  div.className = 'mkt-item';
  div.dataset.key = key;
  div.dataset.name = m.pasaran.toLowerCase();
  div.innerHTML = `
    <div class="dot ${dotClass}"></div>
    <div class="mkt-name">${titleCase(m.pasaran)}</div>
    <span class="mkt-badge ${badgeClass}">${badgeText}</span>`;
  div.addEventListener('click', () => selectMarket(key));
  return div;
}

function filterSidebar(query) {
  document.querySelectorAll('.mkt-item').forEach(el => {
    const show = !query || el.dataset.name.includes(query);
    el.style.display = show ? '' : 'none';
  });
}

// ─────────────────────────────────────────────
// MARKET SELECTION
// ─────────────────────────────────────────────
function selectMarket(key) {
  currentMarket = key;
  document.querySelectorAll('.mkt-item').forEach(el => {
    el.classList.toggle('active', el.dataset.key === key);
  });
  const data = MARKET_DATA[key];
  if (!data) {
    document.getElementById('main-content').innerHTML = '<div class="empty"><div class="empty-icon">⚠️</div><div class="empty-text">Data tidak ditemukan</div></div>';
    return;
  }
  // Scroll sidebar item into view
  const activeEl = document.querySelector('.mkt-item.active');
  if (activeEl) activeEl.scrollIntoView({ block: 'nearest' });

  renderMarket(data);
}

// ─────────────────────────────────────────────
// MAIN MARKET RENDER
// ─────────────────────────────────────────────
function renderMarket(d) {
  const main = document.getElementById('main-content');
  const eligible = d.eligible_for_prediction;

  let html = '';

  // ── PAGE HEADER ─────────────────────────────
  const freshCls = d.data_freshness === 'FRESH' ? 'fresh' : 'stale';
  const freshIcon = d.data_freshness === 'FRESH' ? '●' : '◐';
  html += `
  <div class="page-title">${titleCase(d.pasaran)}</div>
  <div class="page-sub">
    <span class="font-mono">${d.valid_rows} data valid</span>
    &nbsp;|&nbsp; Terakhir: <b>${d.latest_date}</b> → <b style="color:var(--teal)">${d.latest_result||'-'}</b>
    &nbsp;|&nbsp; <span class="${freshCls}">${freshIcon} ${d.data_freshness}</span>
  </div>`;

  // Warnings
  if (d.warnings && d.warnings.length > 0) {
    html += `<div class="warn-banner">⚠ ${d.warnings.map(w=>w.msg).join(' · ')}</div>`;
  }

  if (!eligible) {
    html += `<div class="card"><div class="empty">
      <div class="empty-icon">📊</div>
      <div class="empty-text">Data tidak cukup untuk analisis</div>
      <div class="empty-sub">${d.warnings && d.warnings[0] ? d.warnings[0].msg : 'Minimal 31 data valid diperlukan.'}</div>
    </div></div>`;
    main.innerHTML = html;
    return;
  }

  // ── BBFS 7 DIGIT ────────────────────────────
  html += renderBBFS(d);

  // ── STAT SUMMARY CARDS ─────────────────────
  html += renderStatCards(d);

  // ── TABS: 2D / 3D ──────────────────────────
  html += `
  <div class="tabs">
    <div class="tab ${currentTab==='2d'?'active':''}" onclick="switchTab('2d')">⊞ Kandidat 2D Belakang</div>
    <div class="tab ${currentTab==='3d'?'active':''}" onclick="switchTab('3d')">⊟ Kandidat 3D Belakang</div>
    <div class="tab ${currentTab==='bt'?'active':''}" onclick="switchTab('bt')">📈 Backtest & Validasi</div>
    <div class="tab ${currentTab==='hist'?'active':''}" onclick="switchTab('hist')">🕐 Riwayat</div>
  </div>
  <div id="tab-content">`;
  html += renderTabContent(d, currentTab);
  html += `</div>`;

  // ── DISCLAIMER ─────────────────────────────
  html += `<div class="disclaimer">
    ⚠ <b>DISCLAIMER:</b> ${d.disclaimer || ''}<br>
    <span style="color:rgba(200,100,100,.8)">${d.bbfs_disclaimer || ''}</span>
  </div>`;

  main.innerHTML = html;
}

// ─────────────────────────────────────────────
// BBFS SECTION
// ─────────────────────────────────────────────
function renderBBFS(d) {
  const digits = d.bbfs_digits || [];
  const rejected = d.bbfs_rejected_digits || d.rejected_digits || [];
  const conf = d.bbfs_confidence || 'MEDIUM';
  const status = d.bbfs_status || 'BBFS_READY';
  const limiters = d.bbfs_limiters || [];
  const scores = d.all_digit_scores || {};

  const statusIcon = status === 'BBFS_READY' ? '✓' : status === 'BBFS_READY_WITH_WARNING' ? '⚠' : '✕';
  const statusCls = status === 'BBFS_READY' ? 'status-ok' : status.includes('WARNING') ? 'status-warn' : 'status-err';

  let digitHtml = digits.map((d_,i) => {
    const sc = scores[d_] ? scores[d_].score_normalized : 0;
    return `<div class="digit-bubble ${i===0?'rank1':''}" title="Digit ${d_} · Skor ${sc}">
      ${d_}<div class="score-badge">${sc}</div>
    </div>`;
  }).join('');

  let rejHtml = rejected.map(d_ => `<div class="digit-rejected" title="Digit ${d_}">${d_}</div>`).join('');

  const confCls = conf === 'HIGH' ? 'badge-high' : conf === 'MEDIUM' ? 'badge-med' : 'badge-low';
  const confLabel = conf === 'HIGH' ? 'Tinggi' : conf === 'MEDIUM' ? 'Sedang' : 'Rendah';

  let limiterHtml = limiters.length > 0 ? `<div style="font-size:10px;color:var(--amber);margin-top:8px">⚑ ${limiters.join(' · ')}</div>` : '';

  return `
  <div class="bbfs-section">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <div class="bbfs-title">🎯 BBFS 7 DIGIT UTAMA</div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="${statusCls}">${statusIcon} ${status.replace(/_/g,' ')}</span>
        <span class="mkt-badge ${confCls}">Conf: ${confLabel}</span>
      </div>
    </div>

    <div style="margin-bottom:14px">
      <div style="font-size:9px;color:var(--txt3);letter-spacing:1px;margin-bottom:10px">DIGIT TERPILIH (${digits.length})</div>
      <div class="bbfs-digits">${digitHtml}</div>
    </div>

    <div class="bbfs-meta">
      <span>📦 2D dari BBFS: <b style="color:var(--teal)">${d.bbfs_candidates_2d_count || 0}</b> kombinasi</span>
      <span>📦 3D dari BBFS: <b style="color:var(--teal)">${d.bbfs_candidates_3d_count || 0}</b> kombinasi</span>
      <span>🔢 Ruang kandidat penuh: 100 (2D) · 1.000 (3D) — <i>dipakai audit internal</i></span>
    </div>

    ${rejected.length > 0 ? `
    <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border)">
      <div style="font-size:9px;color:var(--txt3);letter-spacing:1px;margin-bottom:8px">DIGIT TIDAK TERPILIH (${rejected.length})</div>
      <div style="display:flex;gap:6px">${rejHtml}</div>
    </div>` : ''}
    ${limiterHtml}
  </div>`;
}

// ─────────────────────────────────────────────
// STAT CARDS
// ─────────────────────────────────────────────
function renderStatCards(d) {
  const bt = d.backtest_2d || {};
  const gate2d = d.prediction_gate_2d || {};
  const conf2d = d.allowed_max_confidence_2d || 'MEDIUM';
  const hold = d.holdout_2d || {};
  const roll = d.rolling_2d || {};
  const ov = d.overfitting_2d || {};

  const gateCls = gate2d.status === 'LAYAK_PREDIKSI' ? 'status-ok' : gate2d.status === 'PREDIKSI_TERBATAS' ? 'status-warn' : 'status-err';
  const gateIcon = gate2d.status === 'LAYAK_PREDIKSI' ? '✓' : gate2d.status === 'PREDIKSI_TERBATAS' ? '⚑' : '✕';
  const gateLabel = gate2d.status ? gate2d.status.replace(/_/g,' ') : '-';

  const confCls = conf2d === 'HIGH' ? 'good' : conf2d === 'MEDIUM' ? 'warn' : 'bad';
  const confLabel = conf2d === 'HIGH' ? 'TINGGI' : conf2d === 'MEDIUM' ? 'SEDANG' : 'RENDAH';

  const acc10pct = bt.acc10 != null ? (bt.acc10 * 100).toFixed(1) + '%' : '-';
  const rand10pct = '10.0%';
  const uplift = bt.uplift_top10 != null ? (bt.uplift_top10 > 0 ? '+' : '') + (bt.uplift_top10 * 100).toFixed(0) + '%' : '-';
  const upliftCls = bt.uplift_top10 > 0 ? 'good' : bt.uplift_top10 < 0 ? 'bad' : '';

  const holdAcc = hold.acc10 != null ? (hold.acc10 * 100).toFixed(1) + '%' : '-';
  const rollStab = roll.stability_score != null ? (roll.stability_score * 100).toFixed(0) + '%' : '-';
  const champ = (d.champion_challenger_2d || {}).champion || {};

  return `
  <div class="grid4" style="margin-bottom:12px">

    <div class="card">
      <div class="card-title"><span class="icon">⛩</span>Prediction Gate</div>
      <div><span class="${gateCls}">${gateIcon} ${gateLabel}</span></div>
      <div style="font-size:10px;color:var(--txt3);margin-top:6px">${gate2d.reason || ''}</div>
    </div>

    <div class="card">
      <div class="card-title"><span class="icon">🎯</span>Confidence 2D</div>
      <div class="big-val stat-val ${confCls}">${confLabel}</div>
      <div class="big-label">Model: ${champ.name || '-'}</div>
    </div>

    <div class="card">
      <div class="card-title"><span class="icon">📊</span>Backtest Top10 vs Random</div>
      <div class="big-val" style="color:${bt.acc10>0.10?'var(--green)':'var(--red)'}">${acc10pct}</div>
      <div class="big-label">Random: ${rand10pct} &nbsp;|&nbsp; Uplift: <span class="stat-val ${upliftCls}">${uplift}</span></div>
    </div>

    <div class="card">
      <div class="card-title"><span class="icon">🧪</span>Holdout Recent</div>
      <div class="big-val" style="color:${hold.acc10>0.10?'var(--green)':hold.acc10!=null?'var(--amber)':'var(--txt3)'}">${holdAcc}</div>
      <div class="big-label">Status: ${hold.max_confidence_after_holdout || '-'}</div>
    </div>
  </div>`;
}

// ─────────────────────────────────────────────
// TABS
// ─────────────────────────────────────────────
window.switchTab = function(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab').forEach((el, i) => {
    el.classList.toggle('active', ['2d','3d','bt','hist'][i] === tab);
  });
  const d = MARKET_DATA[currentMarket];
  document.getElementById('tab-content').innerHTML = renderTabContent(d, tab);
};

function renderTabContent(d, tab) {
  if (tab === '2d') return renderCandidates2D(d);
  if (tab === '3d') return renderCandidates3D(d);
  if (tab === 'bt') return renderBacktestTab(d);
  if (tab === 'hist') return renderHistoryTab(d);
  return '';
}

// ─────────────────────────────────────────────
// CANDIDATES 2D
// ─────────────────────────────────────────────
function renderCandidates2D(d) {
  const cands = d.top10_2d_from_bbfs || d.display_candidates_2d || [];
  const bbfsDigits = d.bbfs_digits || [];
  const scoreReasons = d.selected_digit_reasons || {};
  const conf = d.allowed_max_confidence_2d || 'LOW';

  if (!cands.length) return '<div class="empty"><div class="empty-icon">📭</div><div class="empty-text">Tidak ada kandidat tersedia</div></div>';

  const maxScore = Math.max(...cands.map(c => c.score || 0), 1);

  let rows = cands.map(c => {
    const barW = Math.round((c.score / maxScore) * 100);
    const confCls = `conf-${c.confidence || conf}`;
    const confLabel = c.confidence === 'HIGH' ? 'TINGGI' : c.confidence === 'MEDIUM' ? 'SEDANG' : 'RENDAH';
    const d1 = c.candidate ? c.candidate[0] : '';
    const d2 = c.candidate ? c.candidate[1] : '';
    const inBBFS1 = bbfsDigits.includes(d1);
    const inBBFS2 = bbfsDigits.includes(d2);
    const candDisplay = `<span style="color:${inBBFS1?'var(--teal)':'var(--txt3)'}">${d1}</span><span style="color:${inBBFS2?'var(--teal)':'var(--txt3)'}">${d2}</span>`;
    return `<tr>
      <td class="rank-num">#${c.rank}</td>
      <td><span class="cand-num">${candDisplay}</span></td>
      <td><div class="score-bar-wrap">
        <div class="score-bar fill-teal" style="width:${barW}%"></div>
        <span class="score-val">${c.score != null ? c.score.toFixed(1) : '-'}</span>
      </div></td>
      <td><span class="conf-pill ${confCls}">${confLabel}</span></td>
      <td style="font-size:10px;color:var(--txt3);max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.reason || ''}</td>
    </tr>`;
  }).join('');

  return `
  <div class="grid2">
    <div class="card">
      <div class="card-title">⊞ Top ${cands.length} Kandidat 2D Belakang — dari BBFS</div>
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>No</th><th>Angka</th><th>Skor</th><th>Conf</th><th>Alasan</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <div style="margin-top:10px;font-size:10px;color:var(--txt3)">
        ✦ Angka berwarna <span style="color:var(--teal)">teal</span> = digit dari BBFS 7 Digit Utama
      </div>
    </div>

    <div>
      ${renderDigitScores(d, '2d')}
    </div>
  </div>`;
}

// ─────────────────────────────────────────────
// CANDIDATES 3D
// ─────────────────────────────────────────────
function renderCandidates3D(d) {
  const cands = d.top10_3d_from_bbfs || d.display_candidates_3d || [];
  const conf = d.allowed_max_confidence_3d || 'LOW';

  if (!cands.length) return '<div class="empty"><div class="empty-icon">📭</div><div class="empty-text">Tidak ada kandidat 3D tersedia</div></div>';
  const maxScore = Math.max(...cands.map(c => c.score || 0), 1);

  let rows = cands.map(c => {
    const barW = Math.round((c.score / maxScore) * 100);
    const confCls = `conf-${c.confidence || conf}`;
    const confLabel = c.confidence === 'HIGH' ? 'TINGGI' : c.confidence === 'MEDIUM' ? 'SEDANG' : 'RENDAH';
    return `<tr>
      <td class="rank-num">#${c.rank}</td>
      <td><span class="cand-num" style="font-size:17px;color:var(--teal)">${c.candidate}</span></td>
      <td><div class="score-bar-wrap">
        <div class="score-bar" style="width:${barW}%;background:var(--blue)"></div>
        <span class="score-val">${c.score != null ? c.score.toFixed(1) : '-'}</span>
      </div></td>
      <td><span class="conf-pill ${confCls}">${confLabel}</span></td>
      <td style="font-size:10px;color:var(--txt3);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.reason || ''}</td>
    </tr>`;
  }).join('');

  const bt3d = d.backtest_3d || {};
  return `
  <div class="grid2">
    <div class="card">
      <div class="card-title">⊟ Top ${cands.length} Kandidat 3D Belakang — dari BBFS</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>No</th><th>Angka</th><th>Skor</th><th>Conf</th><th>Alasan</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>
    <div class="card">
      <div class="card-title">📊 Statistik 3D</div>
      <div class="stat-row"><span class="stat-label">Confidence 3D</span><span class="stat-val ${d.allowed_max_confidence_3d==='HIGH'?'good':d.allowed_max_confidence_3d==='MEDIUM'?'warn':'bad'}">${d.allowed_max_confidence_3d||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Champion Model</span><span class="stat-val">${bt3d.champion_model||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Backtest Total Tests</span><span class="stat-val">${bt3d.total||0}</span></div>
      <div class="stat-row"><span class="stat-label">Top10 Acc</span><span class="stat-val ${(bt3d.acc10||0)>0.01?'good':'bad'}">${bt3d.acc10!=null?(bt3d.acc10*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Top20 Acc</span><span class="stat-val">${bt3d.acc20!=null?(bt3d.acc20*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Baseline Random</span><span class="stat-val">1.0%</span></div>
      <div class="stat-row"><span class="stat-label">BBFS 3D Kandidat</span><span class="stat-val">${d.bbfs_candidates_3d_count||0} komb.</span></div>
    </div>
  </div>`;
}

// ─────────────────────────────────────────────
// DIGIT SCORES CARD
// ─────────────────────────────────────────────
function renderDigitScores(d, type) {
  const scores = d.all_digit_scores || {};
  const selected = d.bbfs_digits || [];
  const digits = ['0','1','2','3','4','5','6','7','8','9'];
  const maxScore = Math.max(...digits.map(d_ => (scores[d_]||{}).score_normalized||0), 1);

  let rows = digits.map(d_ => {
    const sc = (scores[d_]||{}).score_normalized || 0;
    const barW = Math.round((sc / maxScore) * 100);
    const isSel = selected.includes(d_);
    const barColor = isSel ? 'var(--teal)' : 'var(--txt3)';
    return `<div class="slice-row">
      <div style="font-family:var(--mono);font-size:14px;font-weight:700;width:18px;color:${isSel?'var(--teal)':'var(--txt3)'}">${d_}</div>
      <div class="slice-bar-wrap">
        <div class="slice-bar fill-teal" style="width:${barW}%;background:${barColor}"></div>
      </div>
      <div class="slice-val" style="color:${isSel?'var(--teal)':'var(--txt3)'}">${sc}</div>
      ${isSel ? '<span style="font-size:9px;color:var(--teal);font-weight:700">✓</span>' : '<span style="font-size:9px;color:var(--txt3)">✕</span>'}
    </div>`;
  }).join('');

  const selReasons = d.selected_digit_reasons || {};
  const rejReasons = d.rejected_digit_reasons || {};

  let reasonHtml = '';
  if (Object.keys(selReasons).length > 0) {
    reasonHtml = `<div style="margin-top:10px;padding-top:8px;border-top:1px solid var(--border)">
      ${selected.slice(0,3).map(d_ => selReasons[d_] ? `<div style="font-size:10px;color:var(--txt3);margin-bottom:4px"><b style="color:var(--teal)">${d_}:</b> ${selReasons[d_].slice(0,80)}</div>` : '').join('')}
    </div>`;
  }

  return `<div class="card">
    <div class="card-title">🔢 Skor Digit 0–9</div>
    ${rows}
    ${reasonHtml}
  </div>`;
}

// ─────────────────────────────────────────────
// BACKTEST TAB
// ─────────────────────────────────────────────
function renderBacktestTab(d) {
  const bt2d = d.backtest_2d || {};
  const bt3d = d.backtest_3d || {};
  const roll2d = d.rolling_2d || {};
  const roll3d = d.rolling_3d || {};
  const hold = d.holdout_2d || {};
  const ov = d.overfitting_2d || {};
  const ci = d.ci_2d || {};
  const champ = (d.champion_challenger_2d || {});
  const challengers = champ.challengers || [];
  const champ3 = (d.champion_challenger_3d || {});
  const randSim = d.rand_sim_2d || {};

  // Rolling slices
  const roll2dSlices = (roll2d.slices || []).filter(s => s.acc10 != null);
  const roll3dSlices = (roll3d.slices || []).filter(s => s.acc10 != null);

  const rollRows2d = roll2dSlices.map(s => {
    const barW = Math.round((s.acc10 / 0.3) * 100);
    const stCls = s.status === 'STABLE' ? 'slice-stable' : 'slice-unstable';
    return `<div class="slice-row">
      <div class="slice-label">${s.label || (Math.round(s.frac*100)+'%')}</div>
      <div class="slice-bar-wrap">
        <div class="slice-bar" style="width:${Math.min(barW,100)}%;background:${s.acc10>0.10?'var(--green)':'var(--red)'}"></div>
        <div class="slice-bar" style="width:2px;background:var(--amber)" title="Random 10%"></div>
      </div>
      <div class="slice-val">${(s.acc10*100).toFixed(1)}%</div>
      <span class="slice-status ${stCls}">${s.status}</span>
    </div>`;
  }).join('') || '<div style="color:var(--txt3);font-size:11px">Tidak tersedia</div>';

  const rollRows3d = roll3dSlices.map(s => {
    const stCls = s.status === 'STABLE' ? 'slice-stable' : 'slice-unstable';
    return `<div class="slice-row">
      <div class="slice-label">${s.label || (Math.round(s.frac*100)+'%')}</div>
      <div class="slice-bar-wrap">
        <div class="slice-bar" style="width:${Math.min((s.acc10/0.05)*100,100)}%;background:${s.acc10>0.01?'var(--green)':'var(--red)'}"></div>
      </div>
      <div class="slice-val">${(s.acc10*100).toFixed(1)}%</div>
      <span class="slice-status ${stCls}">${s.status}</span>
    </div>`;
  }).join('') || '<div style="color:var(--txt3);font-size:11px">Tidak tersedia</div>';

  const holdSt = hold.max_confidence_after_holdout || '-';
  const holdCls = holdSt === 'HIGH' ? 'good' : holdSt === 'MEDIUM' ? 'warn' : 'bad';

  return `
  <div class="grid2">
    <!-- BACKTEST 2D -->
    <div class="card">
      <div class="card-title">📊 Backtest Walk-Forward 2D</div>
      <div class="stat-row"><span class="stat-label">Champion Model</span><span class="stat-val">${bt2d.champion_model||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Total Test Points</span><span class="stat-val">${bt2d.total||0}</span></div>
      <div class="stat-row"><span class="stat-label">Top-5 Accuracy</span><span class="stat-val ${(bt2d.acc5||0)>0.05?'good':''}">${bt2d.acc5!=null?(bt2d.acc5*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Top-10 Accuracy</span><span class="stat-val ${(bt2d.acc10||0)>0.10?'good':'bad'}">${bt2d.acc10!=null?(bt2d.acc10*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Top-20 Accuracy</span><span class="stat-val ${(bt2d.acc20||0)>0.20?'good':''}">${bt2d.acc20!=null?(bt2d.acc20*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Baseline Random</span><span class="stat-val">10.0%</span></div>
      <div class="stat-row"><span class="stat-label">Sim Random Avg</span><span class="stat-val">${randSim.avg10!=null?(randSim.avg10*100).toFixed(1)+'%':'10.0%'} (${randSim.sims||0} sim)</span></div>
      <div class="stat-row"><span class="stat-label">Uplift Top10</span><span class="stat-val ${(bt2d.uplift_top10||0)>0?'good':'bad'}">${bt2d.uplift_top10!=null?(bt2d.uplift_top10>0?'+':'')+((bt2d.uplift_top10||0)*100).toFixed(0)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">MRR</span><span class="stat-val">${bt2d.mrr||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Rata-rata Rank</span><span class="stat-val">${bt2d.avg_rank||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Obj Score</span><span class="stat-val">${bt2d.obj_score||0}/100</span></div>
      ${ci.lower != null ? `<div class="stat-row"><span class="stat-label">CI 95% Top10</span><span class="stat-val">[${(ci.lower*100).toFixed(1)}% – ${(ci.upper*100).toFixed(1)}%]</span></div>` : ''}
    </div>

    <!-- BACKTEST 3D -->
    <div class="card">
      <div class="card-title">📊 Backtest Walk-Forward 3D</div>
      <div class="stat-row"><span class="stat-label">Champion Model</span><span class="stat-val">${bt3d.champion_model||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Total Test Points</span><span class="stat-val">${bt3d.total||0}</span></div>
      <div class="stat-row"><span class="stat-label">Top-10 Accuracy</span><span class="stat-val ${(bt3d.acc10||0)>0.01?'good':'bad'}">${bt3d.acc10!=null?(bt3d.acc10*100).toFixed(2)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Top-20 Accuracy</span><span class="stat-val">${bt3d.acc20!=null?(bt3d.acc20*100).toFixed(2)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Baseline Random</span><span class="stat-val">1.00%</span></div>
      <br>
      <div class="card-title">🏆 Champion vs Challenger 2D</div>
      <div class="stat-row"><span class="stat-label">Champion</span><span class="stat-val" style="color:var(--teal)">${(champ.champion||{}).name||'-'}</span></div>
      ${challengers.map(c=>`<div class="stat-row"><span class="stat-label">Challenger</span><span class="stat-val">${c.name} <span style="color:var(--txt3)">(${c.obj_score})</span></span></div>`).join('')}
      <br>
      <div class="card-title">🏆 Champion 3D</div>
      <div class="stat-row"><span class="stat-label">Champion</span><span class="stat-val" style="color:var(--blue)">${(champ3.champion||{}).name||'-'}</span></div>
    </div>
  </div>

  <div class="grid2">
    <!-- ROLLING 2D -->
    <div class="card">
      <div class="card-title">🔄 Rolling Validation 2D <span style="font-weight:400;margin-left:8px;font-size:10px;color:${roll2d.is_stable?'var(--green)':'var(--red)'}">${roll2d.is_stable?'✓ STABIL':'✕ TIDAK STABIL'}</span></div>
      <div class="stat-row"><span class="stat-label">Stability Score</span><span class="stat-val ${(roll2d.stability_score||0)>0.6?'good':(roll2d.stability_score||0)>0.4?'warn':'bad'}">${roll2d.stability_score!=null?(roll2d.stability_score*100).toFixed(0)+'%':'-'}</span></div>
      <div style="margin-top:8px">${rollRows2d}</div>
      <div style="font-size:9px;color:var(--txt3);margin-top:6px">Garis kuning = baseline random (10%)</div>
    </div>

    <!-- HOLDOUT + OVERFITTING -->
    <div class="card">
      <div class="card-title">🧪 Holdout Recent Test 2D</div>
      <div class="stat-row"><span class="stat-label">Status</span><span class="stat-val ${holdCls}">${hold.status||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Holdout Periode</span><span class="stat-val">${hold.holdout_from||'-'} – ${hold.holdout_to||'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Holdout Size</span><span class="stat-val">${hold.holdout_count||'-'} draw</span></div>
      <div class="stat-row"><span class="stat-label">Acc Top10</span><span class="stat-val ${holdCls}">${hold.acc10!=null?(hold.acc10*100).toFixed(1)+'%':'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Uplift Top10</span><span class="stat-val">${hold.uplift10!=null?((hold.uplift10>0?'+':'')+((hold.uplift10||0)*100).toFixed(0)+'%'):'-'}</span></div>
      <div class="stat-row"><span class="stat-label">Max Confidence</span><span class="stat-val ${holdCls}">${holdSt}</span></div>
      ${(hold.penalty_reasons||[]).length?`<div style="font-size:10px;color:var(--amber);margin-top:6px">⚑ ${hold.penalty_reasons.join(' · ')}</div>`:''}
      <br>
      <div class="card-title">🛡️ Overfitting Guard 2D</div>
      <div class="stat-row"><span class="stat-label">Detected</span><span class="stat-val ${ov.has_overfitting?'bad':'good'}">${ov.has_overfitting?'⚠ YA':'✓ TIDAK'}</span></div>
      <div class="stat-row"><span class="stat-label">Risk Level</span><span class="stat-val ${ov.risk_level==='HIGH'?'bad':ov.risk_level==='MEDIUM'?'warn':'good'}">${ov.risk_level||'-'}</span></div>
      ${(ov.reasons||[]).map(r=>`<div style="font-size:10px;color:var(--amber);margin-top:3px">• ${r}</div>`).join('')}
    </div>
  </div>`;
}

// ─────────────────────────────────────────────
// HISTORY TAB
// ─────────────────────────────────────────────
function renderHistoryTab(d) {
  const hist = d.recent_history || [];
  if (!hist.length) return '<div class="empty"><div class="empty-icon">📭</div><div class="empty-text">Tidak ada riwayat tersedia</div></div>';

  const rows = hist.map((r, i) => {
    const freshCls = i === 0 ? 'style="color:var(--teal)"' : '';
    return `<div class="hist-row">
      <div class="hist-date">${r.tanggal || '-'}</div>
      <div class="hist-result" ${freshCls}>${r.result || '-'}</div>
      <div class="hist-d3">${r.d3 || '-'}</div>
      <div class="hist-d2">${r.d2 || '-'}</div>
    </div>`;
  }).join('');

  return `
  <div class="card">
    <div class="card-title">🕐 Riwayat 20 Draw Terakhir</div>
    <div style="display:grid;grid-template-columns:90px 60px 60px 40px;gap:8px;padding:4px 6px;font-size:9px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.8px;border-bottom:1px solid var(--border);margin-bottom:4px">
      <div>Tanggal</div><div>Result</div><div>3D Blk</div><div>2D Blk</div>
    </div>
    ${rows}
  </div>`;
}

// ─────────────────────────────────────────────
// UTIL
// ─────────────────────────────────────────────
function titleCase(str) {
  return str.split(' ').map(w => w[0] ? (w[0].toUpperCase() + w.slice(1).toLowerCase()) : w).join(' ');
}
